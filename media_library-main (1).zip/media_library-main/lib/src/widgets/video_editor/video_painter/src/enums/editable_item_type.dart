enum EditableItemType { text, graphic, shape, filter }
