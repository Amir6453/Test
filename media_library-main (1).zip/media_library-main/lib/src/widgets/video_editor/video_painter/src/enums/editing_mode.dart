// ignore_for_file: constant_identifier_names

enum EditorMode {
  NONE,
  FILTERS,
  CROP,
  GRAPHIC,
  TEXT,
  DRAWING,
}
