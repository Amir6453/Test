enum StrokeType { pen, marker, neon }
