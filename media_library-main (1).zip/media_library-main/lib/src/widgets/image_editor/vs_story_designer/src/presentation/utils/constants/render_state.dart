enum RenderState { none, preparing, frames, recording, rendering, saving }
