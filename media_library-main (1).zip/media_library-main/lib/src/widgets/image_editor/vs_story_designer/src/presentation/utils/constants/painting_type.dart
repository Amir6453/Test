enum PaintingType { pen, marker, neon }
