enum RenderType { gif, video }
