class FfmpegPaths {
  static String basePath =
      '/data/user/0/dev.camilo.flutter.vs_story_designer.example.example/cache/';
  static String imagesPath = '$basePath%0d.png';
  static String gifOutputPath = '${basePath}output.gif';
  static String videoOutputPath = '${basePath}output.mp4';
}
